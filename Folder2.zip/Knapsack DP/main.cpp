#include<bits/stdc++.h>
using namespace std;

int KnapSack(int** DP, int* w, int* v, int n, int cap){
    if(n-1 < 0){
        return 0;
    }
    if(DP[n-1][cap] != -1){
        return DP[n-1][cap];
    }
    if(w[n-1] > cap){
        DP[n-1][cap] = KnapSack(DP, w, v, n - 1, cap);
        return DP[n-1][cap];
    }
    else {
        DP[n-1][cap] = max(v[n-1] + KnapSack(DP, w, v, n - 1, cap - w[n - 1]), KnapSack(DP, w, v, n - 1, cap));
        return DP[n-1][cap];
    }
}
int main(){
    int W,n;
    cout << "Enter no.of objects :";
    cin >> n;
    int profit[n],weight[n];
    cout << "Enter weights of objects :" << endl;
    for(int i=0;i<n;i++)
        cin >> weight[i];
    cout << "Enter profits of objects :" << endl;
    for(int i=0;i<n;i++)
        cin >> profit[i];
    cout << "Enter capacity of Knapsack :";
    cin >> W;
    map <int,int> weight_profit;
    for(int i = 0;i<n;i++){
        weight_profit[profit[i]] = weight[i];
    }
    int** DP = (int**) malloc(sizeof(int*)*n);
    for(int i = 0;i<n;i++){
        DP[i] = (int*) malloc(sizeof(int) * W + 1);
    }
    for(int i = 0;i<n;i++){
        for(int j = 0; j < W + 1; j++){
            DP[i][j] = -1;
        }
    }
    int ans = KnapSack(DP, weight, profit, n, W);
    vector <int> weights_included;
    cout << "Maximum Profit :" << ans << endl;
    for(int i = 0;i<n;i++){
        for(int j = 0; j < W + 1; j++){
            cout << DP[i][j] << " ";
        }
        cout << endl;
    }
    int result = 0;
    for(int i = n-2;i>=0;i--){
        int Ans = DP[n-1][W];
        int NewCap = W;
        for(int j = 0; j < W + 1; j++){
            int flag = 0;
            if(DP[i][j] != -1) {
                for (int k = 0; k < n; k++) {
                    int Val = profit[k];
                    if (DP[i][j] + Val == Ans) {
                        weights_included.push_back(Val);
                        result += Val;
                        NewCap = j;
                        flag = 1;
                        break;
                    }
                }
                if(flag == 1){
                    break;
                }
            }
        }
        n -= 1;
        W = NewCap;
    }
    if(ans - result != 0) {
        weights_included.push_back(ans - result);
    }
    sort(weights_included.begin(), weights_included.end());
    for(int i:weights_included){
        cout << i << " ";
    }
    cout<<endl;
    for(int i:weights_included){
        cout << weight_profit[i] << " ";
    }
    cout<<endl;
}