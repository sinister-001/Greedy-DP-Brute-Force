#include <bits/stdc++.h>
using namespace std;

int count(int coins[], int n, int sum)
{
    int i, j, x, y;
    int table[sum + 1][n];
    for (i = 0; i < n; i++)
        table[0][i] = 1;
    for (i = 1; i < sum + 1; i++) {
        for (j = 0; j < n; j++) {
            x = (i - coins[j] >= 0) ? table[i - coins[j]][j] : 0;
            y = (j >= 1) ? table[i][j - 1] : 0;
            table[i][j] = x + y;
        }
    }
    for(int i=0;i<sum+1;i++){
        for(int j=0;j<n;i++){
            cout << table[i][j] << " ";
        }
        cout << endl;
    }
    return table[sum][n - 1];
}

int main()
{
    int n,amt;
    cout << "Enter no.of coins :";
    cin >> n;
    int denom[n];
    cout << "Enter denominations available :" << endl;
    for(int i=0;i<n;i++)
        cin >> denom[i];
    cout << "Enter amount to give change :";
    cin >> amt;
    cout << count(denom, n, amt);
    return 0;
}