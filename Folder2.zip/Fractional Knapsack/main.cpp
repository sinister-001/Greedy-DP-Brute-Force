#include <bits/stdc++.h>
using namespace std;

bool cmp(pair <int,int> &a, pair <int,int> &b)
{
    double r1 = (double)a.first / (double)a.second;
    double r2 = (double)b.first / (double)b.second;
    return r1 > r2;
}

void sort(map <int,int> &M)
{
    vector <pair<int,int>> A;
    for (auto& it : M) {
        A.push_back(it);
    }
    sort(A.begin(), A.end(), cmp);
    for (auto& it : A) {
        cout << it.first << ' '
             << it.second << endl;
    }
}

double FractionalKnapSack(int W, map <int, int> arr, int N)
{
    sort(arr);
    double finalvalue = 0.0;
    for (auto &it : arr) {
        if (it.first<= W) {
            W -= it.first;
            finalvalue += it.second;
        }
        else {
            finalvalue += it.second * ((double)W / (double)it.first);
            break;
        }
    }
    return finalvalue;
}

int main()
{
    int n,W;
    cout << "Enter no.of objets :";
    cin >> n;
    int weight[n],profit[n];
    cout << "Enter weights of objects :" << endl;
    for(int i=0;i<n;i++)
        cin >> weight[i];
    cout << "Enter profits of objects :" << endl;
    for(int i=0;i<n;i++)
        cin >> profit[i];
    cout << "Enter capacity of Knapsack :";
    cin >> W;
    map <int,int> weight_profit;
    for(int i=0;i<n;i++)
        weight_profit[weight[i]]=profit[i];
    cout << FractionalKnapSack(W, weight_profit, n);
    return 0;
}
