#include <bits/stdc++.h>
using namespace std;

int minCoins(int coins[], int m, int V, int table[])
{
    for (int i = 1; i <= V; i++) {
        for (int j = 0; j < m; j++)
            if (coins[j] <= i) {
                int sub_res = table[i - coins[j]];
                if (sub_res != INT_MAX && sub_res + 1 < table[i])
                    table[i] = sub_res + 1;
            }
    }
    if (table[V] == INT_MAX)
        return -1;
    return table[V];
}

int main()
{
    int n,amt;
    cout << "Enter no.of coins :";
    cin >> n;
    int denom[n];
    cout << "Enter all the denominations :" << endl;
    for(int i=0;i<n;i++)
        cin >> denom[i];
    cout << "Enter amount to get change :";
    cin >> amt;
    int table[amt + 1];
    table[0] = 0;
    for (int i = 1; i <= amt; i++)
        table[i] = INT_MAX;
    cout << "Minimum no.of coins :" << minCoins(denom, n, amt, table);
    cout << endl;
    cout << "Amount Tabulation :" << endl;
    for(int i=0;i<amt+1;i++)
        cout << table[i] << " ";
    cout << endl;
    cout << "Coins Used :" << endl;
    for(int i = amt;i>=0;) {
        for(int j = 0;j<n;j++){
            if(i - denom[j] >=0 ) {
                if (table[i] == 1 + table[i - denom[j]]) {
                    cout << denom[j] << " ";
                    i -= denom[j];
                    break;
                }
            }
        }
        if(i<=0)
            return 0;
    }
    return 0;
}