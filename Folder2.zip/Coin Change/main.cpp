#include <bits/stdc++.h>
using namespace std;

int main(){
    int x,n;
    cout<<"Enter the number you want to get change for :";
    cin>>x;
    cout<<"Enter the number of denominations :";
    cin>>n;
    vector<int>v;
    cout<<"Enter the denominations :";
    for(int i=0;i<n;i++){
        int p;
        cin>>p;
        v.push_back(p);
    }
    sort(v.begin(),v.end(),greater<int>());
    vector<int> vec;
    for(int i = 0;i<v.size();i++){
        int k = x/v[i];
        int r = x%v[i];
        vec.push_back(k);
        x = r;
    }
    int sum = 0;
    for(int i=0;i<vec.size();i++){
        sum += vec[i];
    }
    cout<<"Coin Value vs The frequency of the coin used: "<<endl;
    for(int i = 0;i<vec.size();i++){
        cout<<v[i]<<" "<<vec[i]<<endl;
    }
    cout<<"The Coins that we get through Greedy Approach are: "<<sum<<endl;
}