#include <bits/stdc++.h>
using namespace std;

int MatrixChainOrder(int p[], int i, int j)
{
    if (i == j)
        return 0;
    int k;
    int mini = INT_MAX;
    int count;
    for (k = i; k < j; k++)
    {
        count = MatrixChainOrder(p, i, k) + MatrixChainOrder(p, k + 1, j)
                + p[i - 1] * p[k] * p[j];
        mini = min(count, mini);
    }
    return mini;
}

int main()
{
    int n;
    cout << "Enter no.of matrices to be multiplied :";
    cin >> n;
    cout << "Here matrix dimension will be taken as a[i]*a[i+1]" << endl;
    int arr[n+1];
    cout << "Enter dimension :" << endl;
    for(int i=0;i<n+1;i++)
        cin >> arr[i];
    cout << "Minimum number of multiplications :" << MatrixChainOrder(arr, 1, n);
    return 0;
}