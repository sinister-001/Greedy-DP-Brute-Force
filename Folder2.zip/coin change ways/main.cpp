#include <bits/stdc++.h>
using namespace std;

int count(int coins[], int n, int sum)
{
    if (sum == 0)
        return 1;
    if (sum < 0)
        return 0;
    if (n <= 0)
        return 0;
    return count(coins, n - 1, sum) + count(coins, n, sum - coins[n - 1]);
}

int main()
{
    int n,amt;
    cout << "Enter no.of coins :";
    cin >> n;
    int change[n];
    cout << "Enter available denominations :" << endl;
    for(int i=0;i<n;i++)
        cin >> change[i];
    cout << "Enter amount to get change :";
    cin >> amt;
    cout << "Total no.of ways :" << count(change, n, amt);
    return 0;
}